﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace QuanLyDangKi
{
    public class TrainingManagement
    {
        public List<Employee> Employees { get; set; }
        public List<Course> Courses { get; set; }

        public TrainingManagement()
        {
            Employees = new List<Employee>();
            Courses = new List<Course>();
        }

        public void AddEmployee(int employeeNumber, string name, string address, DateTime dateOfBirth)
        {
            if (Employees.Any(e => e.EmployeeNumber == employeeNumber))
            {
                Console.WriteLine("Employee record already exists.");
                return;
            }

            Employee employee = new Employee(employeeNumber, name, address, dateOfBirth);
            Employees.Add(employee);
            Console.WriteLine("Employee record added.");
        }

        public void AddCourse(int courseId, string title, DateTime dateOfCourse, int maxPlaces)
        {
            if (Courses.Any(c => c.CourseId == courseId))
            {
                Console.WriteLine("Course record already exists.");
                return;
            }

            Course course = new Course(courseId, title, dateOfCourse, maxPlaces);
            Courses.Add(course);
            Console.WriteLine("Course record added.");
        }

        public void RegisterEmployeeForCourse(int employeeNumber, int courseId)
        {
            Employee employee = Employees.FirstOrDefault(e => e.EmployeeNumber == employeeNumber);
            Course course = Courses.FirstOrDefault(c => c.CourseId == courseId);

            if (employee == null || course == null)
            {
                Console.WriteLine("Employee or course does not exist.");
                return;
            }

            if (course.RegisteredEmployees.Count >= course.MaxPlaces)
            {
                Console.WriteLine("No places available on the course.");
                return;
            }

            if (employee.Courses.Contains(course))
            {
                Console.WriteLine("Employee is already registered for the course.");
                return;
            }

            employee.Courses.Add(course);
            course.RegisteredEmployees.Add(employee);
            Console.WriteLine("Employee registered for the course.");
        }

        public void RecordCompletionOfCourse(int employeeNumber, int courseId)
        {
            Employee employee = Employees.FirstOrDefault(e => e.EmployeeNumber == employeeNumber);
            Course course = Courses.FirstOrDefault(c => c.CourseId == courseId);

            if (employee == null || course == null)
            {
                Console.WriteLine("Employee or course does not exist.");
                return;
            }

            if (!employee.Courses.Contains(course))
            {
                Console.WriteLine("Employee is not registered for the course.");
                return;
            }

            employee.Courses.Remove(course);
            employee.CompletedCourses.Add(course);
            Console.WriteLine("Employee's completion of the course recorded.");
        }

        public void ViewAllTrainingCourses()
        {
            foreach (var course in Courses)
            {
                Console.WriteLine($"Course ID: {course.CourseId}");
                Console.WriteLine($"Title: {course.Title}");
                Console.WriteLine($"Date of Course: {course.DateOfCourse}");
                Console.WriteLine($"Maximum Places: {course.MaxPlaces}");
                Console.WriteLine("Registered Employees:");

                if (course.RegisteredEmployees.Count == 0)
                {
                    Console.WriteLine("No employees registered for this course.");
                }
                else
                {
                    foreach (var employee in course.RegisteredEmployees)
                    {
                        bool isCompleted = employee.CompletedCourses.Contains(course);
                        Console.WriteLine($"Employee Number: {employee.EmployeeNumber}");
                        Console.WriteLine($"Name: {employee.Name}");
                        Console.WriteLine($"Completed: {(isCompleted ? "Yes" : "No")}");
                    }
                }

                Console.WriteLine();
            }
        }

        public void ViewEmployeeTrainingCourses(int employeeNumber)
        {
            Employee employee = Employees.FirstOrDefault(e => e.EmployeeNumber == employeeNumber);

            if (employee == null)
            {
                Console.WriteLine("Employee does not exist.");
                return;
            }

            Console.WriteLine($"Employee Number: {employee.EmployeeNumber}");
            Console.WriteLine($"Name: {employee.Name}");
            Console.WriteLine("Registered Courses:");

            if (employee.Courses.Count == 0)
            {
                Console.WriteLine("No courses registered for this employee.");
            }
            else
            {
                foreach (var course in employee.Courses)
                {
                    bool isCompleted = employee.CompletedCourses.Contains(course);
                    Console.WriteLine($"Course ID: {course.CourseId}");
                    Console.WriteLine($"Title: {course.Title}");
                    Console.WriteLine($"Completed: {(isCompleted ? "Yes" : "No")}");
                }
            }
        }

        public void SaveDataToFile(string fileName)
        {
            using (StreamWriter writer = new StreamWriter(fileName))
            {
                foreach (var employee in Employees)
                {
                    writer.WriteLine($"{employee.EmployeeNumber},{employee.Name},{employee.Address},{employee.DateOfBirth}");

                    foreach (var course in employee.CompletedCourses)
                    {
                        writer.WriteLine($"{employee.EmployeeNumber},C,{course.CourseId}");
                    }

                    foreach (var course in employee.Courses)
                    {
                        writer.WriteLine($"{employee.EmployeeNumber},R,{course.CourseId}");
                    }
                }
            }

            Console.WriteLine("Data saved to file.");
        }

        public void LoadDataFromFile(string fileName)
        {
            Employees.Clear();
            Courses.Clear();

            using (StreamReader reader = new StreamReader(fileName))
            {
                while (!reader.EndOfStream)
                {
                    string line = reader.ReadLine();
                    string[] parts = line.Split(',');

                    int employeeNumber = int.Parse(parts[0]);
                    string recordType = parts[1];

                    if (recordType == "C") // Completed course record
                    {
                        int courseId = int.Parse(parts[2]);
                        Employee employee = Employees.FirstOrDefault(e => e.EmployeeNumber == employeeNumber);
                        Course course = Courses.FirstOrDefault(c => c.CourseId == courseId);

                        if (employee != null && course != null)
                        {
                            employee.CompletedCourses.Add(course);
                        }
                    }
                    else if (recordType == "R") // Registered course record
                    {
                        int courseId = int.Parse(parts[2]);
                        Employee employee = Employees.FirstOrDefault(e => e.EmployeeNumber == employeeNumber);
                        Course course = Courses.FirstOrDefault(c => c.CourseId == courseId);

                        if (employee != null && course != null)
                        {
                            employee.Courses.Add(course);
                            course.RegisteredEmployees.Add(employee);
                        }
                    }
                    else // Employee record
                    {
                        string name = parts[1];
                        string address = parts[2];
                        DateTime dateOfBirth = DateTime.Parse(parts[3]);

                        Employee employee = new Employee(employeeNumber, name, address, dateOfBirth);
                        Employees.Add(employee);
                    }
                }
            }

            Console.WriteLine("Data loaded from file.");
        }
    }
}
