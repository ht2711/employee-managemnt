﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyDangKi
{
    public class Employee
    {
        public int EmployeeNumber { get; set; }
        public string Name { get; set; }
        public string Address { get; set; }
        public DateTime DateOfBirth { get; set; }
        public List<Course> Courses { get; set; }
        public List<Course> CompletedCourses { get; set; }

        public Employee(int employeeNumber, string name, string address, DateTime dateOfBirth)
        {
            EmployeeNumber = employeeNumber;
            Name = name;
            Address = address;
            DateOfBirth = dateOfBirth;
            Courses = new List<Course>();
            CompletedCourses = new List<Course>();
        }
    }
}
