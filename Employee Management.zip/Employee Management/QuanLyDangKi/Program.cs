﻿
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace QuanLyDangKi
{
    public class Program
    {
        public static void Main(string[] args)
        {
            TrainingManagement trainingManagement = new TrainingManagement();

            int choice = 0;

            do
            {
                Console.WriteLine("1. Add Employee");
                Console.WriteLine("2. Add Course");
                Console.WriteLine("3. Register employee for the course");
                Console.WriteLine("4. Record employee completetion");
                Console.WriteLine("5. View all course");
                Console.WriteLine("6. View employee course");
                Console.WriteLine("7. Add to file");
                Console.WriteLine("8. Dowload information from file");
                Console.WriteLine("9. Quit");
                Console.Write("Your Choice ?: ");
                choice = int.Parse(Console.ReadLine());

                switch (choice)
                {
                    case 1:
                        Console.Write("Add employee number: ");
                        int empNumber = int.Parse(Console.ReadLine());
                        Console.Write("Add employee name: ");
                        string empName = Console.ReadLine();
                        Console.Write("Add employee address: ");
                        string empAddress = Console.ReadLine();
                        Console.Write("Add employee DOB (yyyy-mm-dd): ");
                        DateTime empDateOfBirth = DateTime.Parse(Console.ReadLine());

                        trainingManagement.AddEmployee(empNumber, empName, empAddress, empDateOfBirth);
                        break;

                    case 2:
                        Console.Write("Add Course ID: ");
                        int courseId = int.Parse(Console.ReadLine());
                        Console.Write("Add Course Title: ");
                        string courseTitle = Console.ReadLine();
                        Console.Write("Add date of courses (yyyy-mm-dd): ");
                        DateTime dateOfCourse = DateTime.Parse(Console.ReadLine());
                        Console.Write("Add number of available places: ");
                        int maxPlaces = int.Parse(Console.ReadLine());

                        trainingManagement.AddCourse(courseId, courseTitle, dateOfCourse, maxPlaces);
                        break;

                    case 3:
                        Console.Write("Add employee number: ");
                        int regEmployeeNumber = int.Parse(Console.ReadLine());
                        Console.Write("Add course id: ");
                        int regCourseId = int.Parse(Console.ReadLine());

                        trainingManagement.RegisterEmployeeForCourse(regEmployeeNumber, regCourseId);
                        break;

                    case 4:
                        Console.Write("Add employee number: ");
                        int compEmployeeNumber = int.Parse(Console.ReadLine());
                        Console.Write("Add course id: ");
                        int compCourseId = int.Parse(Console.ReadLine());

                        trainingManagement.RecordCompletionOfCourse(compEmployeeNumber, compCourseId);
                        break;

                    case 5:
                        trainingManagement.ViewAllTrainingCourses();
                        break;

                    case 6:
                        Console.Write("Add employee number: ");
                        int viewEmployeeNumber = int.Parse(Console.ReadLine());

                        trainingManagement.ViewEmployeeTrainingCourses(viewEmployeeNumber);
                        break;

                    case 7:
                        Console.Write("add file name: ");
                        string saveFileName = Console.ReadLine();

                        trainingManagement.SaveDataToFile(saveFileName);
                        break;

                    case 8:
                        Console.Write("add file name: ");
                        string loadFileName = Console.ReadLine();

                        trainingManagement.LoadDataFromFile(loadFileName);
                        break;

                    case 9:
                        Console.WriteLine("Log in to programe...");
                        break;

                    default:
                        Console.WriteLine("Fail.Please try again");
                        break;
                }

                Console.WriteLine();
            } while (choice != 9);
        }
    }

}