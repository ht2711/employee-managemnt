﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuanLyDangKi
{
    public class Course
    {
        public int CourseId { get; set; }
        public string Title { get; set; }
        public DateTime DateOfCourse { get; set; }
        public int MaxPlaces { get; set; }
        public List<Employee> RegisteredEmployees { get; set; }

        public Course(int courseId, string title, DateTime dateOfCourse, int maxPlaces)
        {
            CourseId = courseId;
            Title = title;
            DateOfCourse = dateOfCourse;
            MaxPlaces = maxPlaces;
            RegisteredEmployees = new List<Employee>();
        }
    }
}
